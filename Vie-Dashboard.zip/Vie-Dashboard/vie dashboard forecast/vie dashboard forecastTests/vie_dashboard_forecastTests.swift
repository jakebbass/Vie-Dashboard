//
//  vie_dashboard_forecastTests.swift
//  vie dashboard forecastTests
//
//  Created by Jake Bass on 3/31/25.
//

import Testing

struct vie_dashboard_forecastTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
